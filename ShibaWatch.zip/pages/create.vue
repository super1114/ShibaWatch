<template>
  <div>
    <CreateList />
  </div>
</template>

<script>
import CreateList from '../components/CreateList'

export default {
  components: {
    CreateList: CreateList
}
}
</script>

<style>

</style>
