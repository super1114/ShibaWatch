<template>
  <div>
    <CoinListing />
  </div>
</template>

<script>
import CoinListing from '~/components/CoinListing.vue'

export default {
  components: {
    CoinListing: CoinListing
}
}
</script>

<style>

</style>
