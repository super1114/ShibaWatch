<template>
  <ListingDetails />
</template>

<script>
import ListingDetails from '../components/ListingDetails'

export default {
  components: {
    ListingDetails: ListingDetails
}
}
</script>

<style>

</style>
