<template>
  <Rewards />
</template>

<script>
import Rewards from '../components/Rewards'

export default {
  components: {
    Rewards: Rewards
}
}
</script>

<style>

</style>
