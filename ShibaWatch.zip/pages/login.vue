<template>
  <div>
    <Login />
  </div>
</template>

<script>
import Login from '../components/Login'

export default {
  components: {
    Login: Login
}
}
</script>

<style>

</style>
