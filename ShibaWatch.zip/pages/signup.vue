<template>
  <div>
    <Signup />
  </div>
</template>

<script>
import Signup from '../components/Signup'

export default {
  components: {
    Signup: Signup
}
}
</script>

<style>

</style>
